Amazon Sales Analysis

Overview
The Amazon Sales Analysis project is a Python-based data analysis initiative designed to explore and gain insights from a large dataset of Amazon sales transactions. By leveraging popular Python libraries such as NumPy, Pandas, Matplotlib, and Seaborn, this project aims to clean, analyze, and visualize the data in order to uncover key trends and patterns in Amazon's sales.

Dataset Overview
The dataset consists of 128,976 entries and 21 columns, capturing essential information about each transaction, including:

1.Order ID
2.Date
3.Order Status
4.Sales Channel
5.Quantity
6.Amount
And more.
The data is loaded from a CSV file using Pandas, and an initial inspection with methods like head(), info(), and shape provides an overview of its structure and key characteristics.

Data Cleaning and Preprocessing
Before analysis, the dataset undergoes several cleaning steps:

Dropping Irrelevant Columns: Columns such as 'New' and 'PendingS' that don't provide useful information are removed.
Handling Missing Data: Missing values are addressed by either dropping rows or filling in gaps with appropriate values.
Data Type Conversion: Columns such as 'Date' are converted into datetime objects to enable time-based analysis, and other columns are adjusted for consistency.
These steps ensure the dataset is ready for more advanced analysis.

Exploratory Data Analysis (EDA)
1. Size Distribution
The distribution of product sizes (e.g., S, M, L) is explored using count plots, revealing that M-Size is the most popular size among buyers.

2. Sales by Size
Grouping the data by size allows us to analyze the quantity of products sold for each size. The findings confirm that M-Size products dominate the sales volume.

3. Order and Shipping Status
By analyzing shipping methods and order statuses through count plots, it becomes clear that the majority of orders are shipped via courier services.

4. Product Category Distribution
A histogram visualizes the distribution of sales across different product categories, highlighting that T-shirts are the most frequently purchased item.

5. B2B vs Retailer Distribution
A pie chart is used to show the proportion of Business-to-Business (B2B) vs retail customers. The analysis reveals that 99.3% of buyers are individual retail customers.

6. Fulfillment Methods
A pie chart also illustrates the breakdown of fulfillment methods, showing that Amazon is the primary fulfillment service used for orders.

7. Geographic Distribution
Scatter plots are used to analyze the relationship between product categories and sizes. Additionally, state-wise distribution plots reveal the geographic concentration of buyers, with Maharashtra having the highest number of customers.

Key Findings and Insights
The analysis provides several valuable insights, including:

The dominance of M-Size products in terms of both quantity and popularity.
The preference for T-shirts across all product categories.
The overwhelming prevalence of retail customers over B2B clients.
The geographic concentration of buyers, particularly in Maharashtra.
These insights can help businesses optimize inventory management, understand customer preferences, and tailor marketing strategies to specific geographic regions.

Conclusion
The Amazon Sales Analysis project offers an in-depth look into customer behavior, product popularity, and geographic trends. By leveraging these insights, businesses can make more informed decisions to enhance customer satisfaction, improve inventory management, and drive sales growth.

